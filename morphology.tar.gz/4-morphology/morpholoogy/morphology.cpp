#include <morphology.hpp>

using namespace cv;

void
mm(Mat se, Mat ims, Mat imd, void (*pf)(uchar, uchar*))
{
  (void) se;
  (void) ims;
  (void) imd;
  (void) pf;
}

void
maximum(uchar val, uchar* max)
{
  (void) val;
  (void) max;
}

void
minimum(uchar val, uchar* min)
{
  (void) val;
  (void) min;
}

